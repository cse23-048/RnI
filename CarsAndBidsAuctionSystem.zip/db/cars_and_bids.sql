
CREATE DATABASE cars_and_bids;
USE cars_and_bids;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cars (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(100),
  description TEXT,
  model VARCHAR(50),
  year INT,
  mileage INT,
  image VARCHAR(255),
  current_bid DECIMAL(10,2) DEFAULT 0.00,
  buy_now_price DECIMAL(10,2),
  is_sold BOOLEAN DEFAULT FALSE
);

CREATE TABLE bids (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  car_id INT,
  amount DECIMAL(10,2),
  bid_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (car_id) REFERENCES cars(id)
);
