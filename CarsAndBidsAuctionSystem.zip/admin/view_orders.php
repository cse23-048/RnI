<?php
// See who bid or bought
?>