<?php
// Buy now logic
?>