<?php
// DB connection logic
?>