<?php
// User registration handler
?>