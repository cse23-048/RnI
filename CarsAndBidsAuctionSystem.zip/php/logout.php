<?php
// Logout session handler
?>