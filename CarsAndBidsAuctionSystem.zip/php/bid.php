<?php
// Process user bid
?>